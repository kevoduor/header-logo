import { OrganicSphere } from './components/OrganicSphere/OrganicSphere';

function App() {
  return (
    <div className="min-h-screen bg-gray-900 flex items-center justify-center p-4">
      <div className="flex items-center gap-8">
        <div className="w-48 h-48">
          <OrganicSphere />
        </div>
        <h1 
          className="text-6xl font-sf-pro text-white tracking-[0.2em]"
          style={{
            textShadow: '0 0 20px rgba(255, 255, 255, 0.5)',
            fontVariant: 'small-caps',
            fontWeight: 500,
          }}
        >
          niah
        </h1>
      </div>
    </div>
  );
}

export default App;