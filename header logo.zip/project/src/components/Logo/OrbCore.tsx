import React from 'react';
import { useOrbAnimation } from './useOrbAnimation';

export function OrbCore() {
  const { scale } = useOrbAnimation();
  
  return (
    <g transform={`scale(${scale})`}>
      <circle
        cx="256"
        cy="256"
        r="180"
        fill="url(#orb-gradient)"
        filter="url(#glow)"
        className="transition-transform duration-200 ease-in-out"
      />
    </g>
  );
}