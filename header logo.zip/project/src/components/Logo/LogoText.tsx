import React from 'react';

export function LogoText() {
  return (
    <text
      x="50%"
      y="65%"
      textAnchor="middle"
      className="text-4xl fill-white font-sf-pro"
      style={{
        filter: 'url(#glow)',
        fontFamily: 'SF Pro Display',
      }}
    >
      NIAH
    </text>
  );
}