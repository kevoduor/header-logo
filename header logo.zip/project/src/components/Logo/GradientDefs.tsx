import React from 'react';

export function GradientDefs() {
  return (
    <defs>
      <radialGradient id="orb-gradient" cx="50%" cy="50%" r="50%" fx="50%" fy="50%">
        <stop offset="0%" style={{ stopColor: '#4f46e5', stopOpacity: 0.9 }} />
        <stop offset="45%" style={{ stopColor: '#6366f1', stopOpacity: 0.8 }} />
        <stop offset="100%" style={{ stopColor: '#7c3aed', stopOpacity: 0.6 }} />
      </radialGradient>
      <filter id="glow">
        <feGaussianBlur stdDeviation="8" result="coloredBlur" />
        <feMerge>
          <feMergeNode in="coloredBlur" />
          <feMergeNode in="SourceGraphic" />
        </feMerge>
      </filter>
    </defs>
  );
}